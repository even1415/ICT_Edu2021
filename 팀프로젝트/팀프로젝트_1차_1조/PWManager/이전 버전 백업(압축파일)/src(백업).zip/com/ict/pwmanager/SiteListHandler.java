package com.ict.pwmanager;

import java.awt.Desktop;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

public class SiteListHandler implements ActionListener {
	private SiteListPanel siteLP; //View
	private SiteAddPanel siteAEP;
	private SiteListDAO siteLDao; //Model
	SiteListVO siteLVO;
	List<SiteListVO> arr;
	private String uriString; //uri ������ ���ڿ�
	private String clipString; //Ŭ�����忡 ������ ���ڿ�
	
	public SiteListHandler(SiteListPanel siteLP) {
		this.siteLP = siteLP;
		this.siteLDao = new SiteListDAO();
		showList();
	}
	
	public void addSiteContent() {
		siteLP.AddDataButton.addActionListener(this);
	}
	
	public void showList() {
		arr = siteLDao.siteList();
		//siteLP.showEmpTable(arr);
		//siteLP. 
		
		Iterator<SiteListVO> it = arr.iterator();
//		while(it.hasNext()) {
//			siteLVO = it.next();
//			//System.out.println(siteLVO.getKey() + " / " + siteLVO.getSiteID() + " / " + siteLVO.getURL());
//		}
	}
	
	public void ClipBoardLink() { //Ŭ�����忡 �ؽ�Ʈ �����ϴ� �޼ҵ�
		clipString = "https://www.naver.com/"; //������ �ؽ�Ʈ

		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		StringSelection strSel = new StringSelection(clipString);
		clipboard.setContents(strSel, null);
	}
	
	public void GotoWebpage() { //�������� �̵��ϴ� �޼ҵ�
		if (Desktop.isDesktopSupported()) {
			Desktop desktop = Desktop.getDesktop();
			try {
				URI uri = new URI("https://www.naver.com/"); //�̵��� URL
				//���� uriString ������ �����ؼ� ���� ���� �ʿ�
				desktop.browse(uri);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (URISyntaxException e) {
				e.printStackTrace();
			}
		}
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		Object obj = e.getSource();
		
		if(obj==siteLP.AddDataButton) {
			siteLP.main.card.show(siteLP.main.p, "AddEdit");
			//siteLP.revalidate();
		}
		if(obj==siteLP.BackButton) {
			
		}
//		if(obj==) {
//			ClipBoardLink();
//			GotoWebpage();
//		}
	}
}
