package com.ict.pwmanager;

import java.sql.SQLException;
import java.util.*;
import jdbc.util.DBUtil;

public class SiteListDAO extends DAOBase {
	public List<SiteListVO> siteList() {
		try {
			con = DBUtil.getCon();
			String sql = "select key, sitename, url, siteid, sitepw, insertdate, guardlevel, category"
					 + " from sitelist where key = " + "1002";
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			
			List<SiteListVO> arr = new ArrayList<>();
			while(rs.next()) {
				int key = rs.getInt("key");
				String siteName = rs.getString("sitename");
				String URL = rs.getString("url");
				String siteID = rs.getString("siteid");
				String sitePW = rs.getString("sitepw");
				java.sql.Date insertDate = rs.getDate("insertDate");
				int guardLevel = rs.getInt("guardlevel");
				int category = rs.getInt("category");
				
				SiteListVO eachlist = new SiteListVO(key, siteName, URL, siteID, sitePW, insertDate, guardLevel, category);
				arr.add(eachlist);
				
			}
			return arr;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} finally {
			close();
		}
	}
	
	public int deleteData(int key) {
		try {
			con = DBUtil.getCon();
			String sql = "delete from sitelist where key=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, key);
			int n = ps.executeUpdate();
			return n;
		} catch (SQLException e) {
			e.printStackTrace();
			return -1;
		} finally {
			close();
		}
	}

}