package com.ict.pwmanager;

import java.sql.SQLException;
import jdbc.util.DBUtil;

public class SiteAddDAO extends DAOBase {
	public int insertSiteData(SiteListVO vo) {
		try {
			con = DBUtil.getCon();
			//insert�� �ۼ� => ps��� => executeXXX() => ��ȯ�ϱ�
			String sql = "INSERT INTO SITELIST(key, sitename, url, siteid, sitepw, "
					+ " insertdate, guardlevel, category)"
					+ " VALUES(?, ?, ?, ?, ?, sysdate, ?, ?)";
			
			ps = con.prepareStatement(sql);
			ps.setInt(1, 1002 /*vo.getKey()*/); //�׽�Ʈ�ڵ�,���� ������ ��
			ps.setString(2, vo.getSiteName());
			ps.setString(3, vo.getURL());
			ps.setString(4, vo.getSiteID());
			ps.setString(5, EncryptAlgorithm(vo.getSitePW(), vo.getGuardLevel())); //��ȣȭ �� DB����
			ps.setInt(6, vo.getGuardLevel());
			ps.setInt(7, 0 /*vo.getCategory()*/); //�׽�Ʈ�ڵ�,���� ������ ��
			
			int n = ps.executeUpdate();
			return n;
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
			return -1;
		} finally {
			close();
		}
	}
	
	private String EncryptAlgorithm(String s, int GuardLevel) {
		//���� �б��� �߰� �ʿ�(GuardLevel�� ����)
		CasearAlgoEncrypt(s);
		return s;
	}
	
	private String CasearAlgoEncrypt(String s) {
		char[] st = s.toCharArray();
		char[] ch = new char[st.length];

		String word = "";
		for (int i = 0; i < st.length; i++) {
			int num = (int) st[i];

			if (65 <= num && num <= 90) {
				if (num + 3 > 90)
					num -= 26;

			} else if (97 <= num && num <= 122) {
				if (num + 3 > 122)
					num -= 26;

			} else if (48 <= num && num <= 57) {
				if (num + 3 > 57)
					num -= 10;

			} else {
				if (65 <= (num + 3) && (num + 3) <= 90)
					num += 26;
				if (97 <= (num + 3) && (num + 3) <= 122)
					num += 26;
				if (48 <= (num + 3) && (num + 3) <= 57)
					num += 10;
				if ((num + 3) > 126)
					num -= 94;
			}
			num += 3;
			ch[i] = (char) num;
			word += String.valueOf(ch[i]);
		}
		
		return word;
	}
}
