package com.ict.pwmanager;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;

public class PWManager extends JFrame {

	PWManager main;
	JPanel p;
	CardLayout card;
	LoginPanel lginP = new LoginPanel(this);
	SignupPanel siupP = new SignupPanel(this);

	public PWManager() {
		super("::PWManager::");
		Container cp = this.getContentPane();
		p = new JPanel();
		p.setBackground(Color.white);
		cp.add(p, BorderLayout.CENTER);
		
		p.setLayout(card = new CardLayout()); //카드레이아웃 설정
		p.add(lginP, "login"); //로그인페이지 부착
		p.add(siupP, "signup"); //회원가입페이지 부착
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		PWManager my = new PWManager();
		my.setSize(432, 768);
		my.setVisible(true);
	}

}