package com.ict.pwmanager;

import jdbc.util.DBUtil;
import java.sql.*;
import java.sql.Date;
import java.util.*;

public class LoginDAO extends DAOBase {

	LoginVO loginVO;

	public int login(LoginVO vo) {
		String tID;
		String tPW;

		try {
			con = DBUtil.getCon();
			String sql = "SELECT KEY, ID, NAME, PASSWORD, JOINDATE "
						+ " FROM USERDATA WHERE ID = ? AND PASSWORD = ?";
			
			ps = con.prepareStatement(sql);
			ps.setString(1, vo.getuID());
			ps.setString(2, vo.getuPW());
			
			rs = ps.executeQuery();
			while (rs.next()) {
				tID = rs.getString("ID");
				tPW = rs.getString("PASSWORD");
				
				if (vo.getuID().equals(tID) && vo.getuPW().equals(tPW)) {
					// System.out.println("로그인 성공");
					int key = rs.getInt(1);
					String iD = rs.getString(2);
					String name = rs.getString(3);
					String pW = rs.getString(4);
					Date date = rs.getDate(5);
					
					loginVO = new LoginVO(key, iD, name, pW, date);
					return 1;
				} else {
					// System.out.println("패스워드 다름");
					return 0;
				}
			}
			// System.out.println("아이디 존재하지 않음");
			return -1;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		// System.out.println("DB 에러");
		return -2;
	}

}