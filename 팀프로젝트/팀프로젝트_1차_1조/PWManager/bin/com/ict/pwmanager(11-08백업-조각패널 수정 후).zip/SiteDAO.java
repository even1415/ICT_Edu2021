package com.ict.pwmanager;

import java.sql.SQLException;
import java.util.*;
import jdbc.util.DBUtil;

public class SiteDAO extends DAOBase {
	public List<SiteVO> siteList() {
		try {
			con = DBUtil.getCon();
			String sql = "select key, sitekey, sitename, url, siteid, sitepw, insertdate, guardlevel, category"
					 + " from sitelist where key = " + "1002";
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			
			List<SiteVO> arr = new ArrayList<>();
			while(rs.next()) {
				int key = rs.getInt("key");
				int sitekey = rs.getInt("sitekey");
				String siteName = rs.getString("sitename");
				String URL = rs.getString("url");
				String siteID = rs.getString("siteid");
				String sitePW = rs.getString("sitepw");
				java.sql.Date insertDate = rs.getDate("insertDate");
				int guardLevel = rs.getInt("guardlevel");
				int category = rs.getInt("category");
				
				SiteVO eachlist = new SiteVO(key, sitekey, siteName, URL, siteID, sitePW, insertDate, guardLevel, category);
				arr.add(eachlist);
				
			}
			return arr;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} finally {
			close();
		}
	}
	
	public int insertSiteData(SiteVO vo) {
		try {
			con = DBUtil.getCon();
			//insert�� �ۼ� => ps��� => executeXXX() => ��ȯ�ϱ�
			String sql = "INSERT INTO SITELIST(key, sitekey, sitename, url, siteid, sitepw, "
					+ " insertdate, guardlevel, category)"
					+ " VALUES(?, site_seq.nextval, ?, ?, ?, ?, sysdate, ?, ?)";
			
			ps = con.prepareStatement(sql);
			ps.setInt(1, 1002 /*vo.getKey()*/); //�׽�Ʈ�ڵ�,���� ������ ��
			ps.setString(2, vo.getSiteName());
			ps.setString(3, vo.getURL());
			ps.setString(4, vo.getSiteID());
			ps.setString(5, EncryptAlgorithm(vo.getSitePW(), vo.getGuardLevel())); //��ȣȭ �� DB����
			ps.setInt(6, vo.getGuardLevel());
			ps.setInt(7, 0 /*vo.getCategory()*/); //�׽�Ʈ�ڵ�,���� ������ ��
			
			int n = ps.executeUpdate();
			return n;
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
			return -1;
		} finally {
			close();
		}
	}
	
	private String EncryptAlgorithm(String s, int GuardLevel) {
		//���� �б��� �߰� �ʿ�(GuardLevel�� ����)
		CasearAlgoEncrypt(s);
		return s;
	}
	
	private String CasearAlgoEncrypt(String s) {
		char[] st = s.toCharArray();
		char[] ch = new char[st.length];

		String word = "";
		for (int i = 0; i < st.length; i++) {
			int num = (int) st[i];

			if (65 <= num && num <= 90) {
				if (num + 3 > 90)
					num -= 26;

			} else if (97 <= num && num <= 122) {
				if (num + 3 > 122)
					num -= 26;

			} else if (48 <= num && num <= 57) {
				if (num + 3 > 57)
					num -= 10;

			} else {
				if (65 <= (num + 3) && (num + 3) <= 90)
					num += 26;
				if (97 <= (num + 3) && (num + 3) <= 122)
					num += 26;
				if (48 <= (num + 3) && (num + 3) <= 57)
					num += 10;
				if ((num + 3) > 126)
					num -= 94;
			}
			num += 3;
			ch[i] = (char) num;
			word += String.valueOf(ch[i]);
		}
		
		return word;
	}

	public int deleteData(int key) {
		try {
			con = DBUtil.getCon();
			String sql = "delete from sitelist where key=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, key);
			int n = ps.executeUpdate();
			return n;
		} catch (SQLException e) {
			e.printStackTrace();
			return -1;
		} finally {
			close();
		}
	}
	
	public SiteVO getSiteVO(String siteKey) {
		try {
			con = DBUtil.getCon();
			String sql = "select key, sitekey, sitename, url, siteid, sitepw, insertdate, guardlevel, category"
					+ " from sitelist where sitekey=" + siteKey;
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			
			int key = rs.getInt("key");
			int sitekey = rs.getInt("sitekey");
			String siteName = rs.getString("sitename");
			String URL = rs.getString("url");
			String siteID = rs.getString("siteid");
			String sitePW = rs.getString("sitepw");
			java.sql.Date insertDate = rs.getDate("insertDate");
			int guardLevel = rs.getInt("guardlevel");
			int category = rs.getInt("category");
			
			SiteVO siteVO = new SiteVO(key, sitekey, siteName, URL, siteID, sitePW, insertDate, guardLevel, category);
			
			return siteVO;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} finally {
			close();
		}
		
	}
}