package com.ict.pwmanager;

import java.awt.Desktop;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class EachDataHandler implements ActionListener {
	EachDataPanel edp;
	SiteVO siteVO;
	private String urlString; //url ������ ���ڿ�
	private String clipString; //Ŭ�����忡 ������ ���ڿ�
	
	public EachDataHandler(EachDataPanel edp) {
		this.edp=edp;
	}
	
	public void ClipBoardLink(String clipString) { //Ŭ�����忡 �ؽ�Ʈ �����ϴ� �޼ҵ�
		this.clipString = clipString; //���� ���� ���� �ʿ�

		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		StringSelection strSel = new StringSelection(clipString);
		clipboard.setContents(strSel, null);
	}
	
	public void GotoWebpage(String urlString) { //�������� �̵��ϴ� �޼ҵ�
		this.urlString = urlString; //���� ���� ���� �ʿ�
		
		if (Desktop.isDesktopSupported()) {
			Desktop desktop = Desktop.getDesktop();
			try {
				URI uri = new URI(urlString); //�̵��� URL
				desktop.browse(uri);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (URISyntaxException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object obj = e.getSource();
		System.out.println(e.getActionCommand()+"<<<"); //test code
		
		if(obj==edp.GoWebSite) {
			//siteVO = siteDAO.getSiteVO(e.getActionCommand());
			
			GotoWebpage(siteVO.getURL());
			ClipBoardLink(siteVO.getSitePW());
		}
		if(obj==edp.DeleteData) {
			
		}
		
		
	}

}
