package com.board.model;

public class BoardVO {
	private int idx;
	private String name;
	private String subject;
	private String content;
	
	public BoardVO() {
		
	}

	public BoardVO(int idx, String name, String subject, String content) {
		super();
		this.idx = idx;
		this.name = name;
		this.subject = subject;
		this.content = content;
	}

	//setter, getter------------------------------
	public int getIdx() {
		return idx;
	}

	public void setIdx(int idx) {
		this.idx = idx;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
}
