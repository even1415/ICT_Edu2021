package com.ict.pwmanager;

import java.awt.event.*;
import java.util.List;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class SiteViewHandler implements ActionListener, KeyListener {

	SiteViewPanel siteVP;
	SiteEditHandler siteEH;
	private LoginVO loginVO;
	SiteVO listVO;

	public SiteViewHandler(SiteViewPanel siteVP) {
		this.siteVP = siteVP;
	}
	

//	public SiteViewHandler(SiteEditHandler siteEH) {
//		this.siteEH = siteEH;
//	}


	public void getVOData() {
		listVO=new SiteVO();
		listVO.setSitekey(10004);
		listVO.setSiteName("ZOOM");
		listVO.setURL("https://zoom.us/");
		listVO.setSiteID("park");
		listVO.setSitePW("pk1234@!");
//		listVO.setInsertDate(insertDate)
//		siteID="park";
//		sitePW="pk1234@!";
//		insertDate;
//		guardLevel;
//		category;
		
//		return listVO; 
	}
	
	@SuppressWarnings("deprecation")
	public void checkPW() {
		loginVO = new LoginVO();
		listVO = new SiteVO();
		getVOData();
		String uPW = loginVO.getuPW();
		String sID = listVO.getSiteID();
		String sPW = listVO.getSitePW();
		String inputPW;
		inputPW = siteVP.pwTf.getText();
		if (uPW.equals(inputPW)) {
			siteVP.sPWTa.setText("사이트 아이디 : " + sID + "\n나의 비밀번호 : " + casearAlgoDecrypt(sPW));
		} else {
			siteVP.sPWTa.setText("비밀번호가 일치하지 않습니다.");
		}
	}
	
	public void resetTa() {
		siteVP.pwTf.setText("");
		siteVP.sPWTa.setText("");
	}

	public String casearAlgoDecrypt(String sitePW) {
		String myPW = "";
		char[] st;
		st = sitePW.toCharArray();
		char[] ch = new char[st.length];
//		process(a,b,c);
		
		for (int i = 0; i < st.length; i++) {
			int num = (int) st[i];
			if (65 <= num && num <= 90) {
				if (num - 3 < 65)
					num += 26;
			} else if (97 <= num && num <= 122) {
				if (num - 3 < 97)
					num += 26;
			} else if (48 <= num && num <= 57) {
				if (num - 3 < 48)
					num += 10;
			} else {
				if (65 <= (num - 3) && (num - 3) <= 90)
					num -= 26;
				if (97 <= (num - 3) && (num - 3) <= 122)
					num -= 26;
				if (48 <= (num - 3) && (num - 3) <= 57)
					num -= 10;
				if ((num - 3) < 33)
					num += 94;
			}
			num -= 3;
			ch[i] = (char) num;
			myPW += String.valueOf(ch[i]);
		}
		return myPW;
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if (obj == siteVP.backBtn) {
			//list패널로 이동
			siteVP.main.card.show(siteVP.main.p, "ListP");
		}
		if (obj == siteVP.editBtn) {
			//edit패널로 이동
			//resetTa();
			siteVP.main.card.show(siteVP.main.p, "EditP");
		}
		if (obj == siteVP.pwBtn) {
			//비밀번호 확인
			checkPW();
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		//엔터를 눌러도 이벤트가 발생함
		if(e.getKeyCode()==KeyEvent.VK_ENTER) {
			checkPW();
		}
	}
	public void keyTyped(KeyEvent e) {}
	public void keyReleased(KeyEvent e) {}

	public void backButtonEvent() {
		siteVP.backBtn.addActionListener(this);
	}


}
