package com.ict.pwmanager;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;

public class PWManager extends JFrame {
	
	JPanel p;
	JButton b;
	SiteListPanel listP = new SiteListPanel(this);
	SiteViewPanel viewP = new SiteViewPanel(this);
	SiteEditPanel editP = new SiteEditPanel(this,viewP);
	//카드레이아웃 변수선언
	CardLayout card;
	PWManager main;

	public PWManager() {

		super("::PWManager::");
		Container cp = this.getContentPane();
		p = new JPanel();
		p.setBackground(Color.white);
		cp.add(p);
		
		//p의 레이아웃을 카드레이아웃으로 설정
		p.setLayout(card = new CardLayout());
		//p에 내가 만든 패널을 부착, 별칭을 꼭 지정해주어야 함
		p.add(viewP, "ViewP");
		p.add(listP, "ListP");
		p.add(editP, "EditP");
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}// 생성자------------------------------------------------------------------

	public static void main(String[] args) {
		PWManager my = new PWManager();
		my.setSize(432, 768);
		my.setVisible(true);
		my.setLocationRelativeTo(null);
	}// main()-------------------

}// class