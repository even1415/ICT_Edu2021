package com.ict.pwmanager;

import java.sql.*;
import jdbc.util.DBUtil;

public class SiteDAO extends DAOBase {
	
	public int updateSiteData(SiteVO vo) {

		try {
			con = DBUtil.getCon();
			String sql = "UPDATE sitelist SET sitename = ?, url = ?, siteid = ?, sitepw = ?, "
					+ " guardlevel = ?, category = ? WHERE sitekey = ?";
			ps = con.prepareStatement(sql);
			
			ps.setString(1, vo.getSiteName());
			ps.setString(2, vo.getURL());
			ps.setString(3, vo.getSiteID());
			ps.setString(4, CasearAlgoEncrypt(vo.getSitePW()));
			ps.setInt(5, vo.getGuardLevel());
			ps.setInt(6, vo.getCategory());
			ps.setInt(7, vo.getSitekey());

			int n = ps.executeUpdate();
			return n;

		} catch (SQLException e) {
			e.printStackTrace();
			return -1;
		} finally {
			close();
		}
	}

	private String CasearAlgoEncrypt(String s) {
		char[] st = s.toCharArray();
		char[] ch = new char[st.length];

		String word = "";
		for (int i = 0; i < st.length; i++) {
			int num = (int) st[i];

			if (65 <= num && num <= 90) {
				if (num + 3 > 90)
					num -= 26;

			} else if (97 <= num && num <= 122) {
				if (num + 3 > 122)
					num -= 26;

			} else if (48 <= num && num <= 57) {
				if (num + 3 > 57)
					num -= 10;

			} else {
				if (65 <= (num + 3) && (num + 3) <= 90)
					num += 26;
				if (97 <= (num + 3) && (num + 3) <= 122)
					num += 26;
				if (48 <= (num + 3) && (num + 3) <= 57)
					num += 10;
				if ((num + 3) > 126)
					num -= 94;
			}
			num += 3;
			ch[i] = (char) num;
			word += String.valueOf(ch[i]);
		}

		return word;
	}
}
