package com.ict.pwmanager;

public class SiteListVO {

}
