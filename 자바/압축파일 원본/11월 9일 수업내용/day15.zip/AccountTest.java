package day15;

public class AccountTest {

	public static void main(String[] args) {
		Account ac=new Account();
		
		UserIn u1=new UserIn("����", ac);
		//UserIn u3=new UserIn("����", ac);
		UserOut u2=new UserOut("��¯��", ac);
		//UserOut u4=new UserOut("��¯��", ac);
		
		u2.start();
		u1.start();
		//u3.start();
		//u4.start();

	}

}
