package day15;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;

public class MyDemo extends JFrame {
	JPanel p;

	Snail sp;
	JButton btStart, btStop;
	public MyDemo() {
		super("::MyDemo::");
		Container cp = this.getContentPane();
		p = new JPanel();
		p.setBackground(Color.white);
		cp.add(p, BorderLayout.NORTH);
		
		sp=new Snail();
		cp.add(sp, BorderLayout.CENTER);
		
		p.add(btStart=new JButton("Start"));
		p.add(btStop=new JButton("Stop"));
		//������ ����---
		MyHandler handler=new MyHandler();
		btStart.addActionListener(handler);
		btStop.addActionListener(handler);

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}//������----------------
	
	
	class MyHandler implements ActionListener{
		Thread tr;
		public void actionPerformed(ActionEvent e) {
			Object o=e.getSource();
			if(o==btStart) {
				//������ ����
				sp.isStop=false;
				tr=new Thread(sp);
				tr.start();
			}else if(o==btStop) {
				//������ ����
				sp.isStop=true;
				tr.interrupt();
			}
			
		}
	}

	public static void main(String[] args) {
		MyDemo my = new MyDemo();
		my.setSize(500, 500);
		my.setVisible(true);
	}//main()

}//class
