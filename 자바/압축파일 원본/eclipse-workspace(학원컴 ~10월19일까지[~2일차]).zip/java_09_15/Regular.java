package java_09_27;

public class Regular extends Employee {
	
	
	public Regular(String name, int age, String address, String dept,int salary) {
		super(name,age,address,dept);
		super.setSalary(salary);
	}
	
	@Override
	public void printInfo() {
		super.printInfo();	
		System.out.println("����: " + super.getSalary());
		
	}
	
	
}
