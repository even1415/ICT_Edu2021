import java.util.Scanner;
//��� ���� static ���� = ���� ���� = ���� ����
class A{
	static int num =0;
	int num2 =0; //�ν��Ͻ� ����
	
}

class Grade {
	private int kor;
	private int math;
	private int eng;

	Grade() {
	}

	Grade(int kor, int math, int eng) {
		this.kor = kor;
		this.math = math;
		this.eng = eng;
	}

	public double getAvg() {
		return (kor + math + eng) / 3.0;
	}

}

class CountBill {
	public void printBill(int money) {

		System.out.println("������ : " + money / 50000 + "��");
		System.out.println("���� : " + (money % 50000) / 10000 + "��");
		System.out.println("��õ�� : " + (money % 10000) / 5000 + "��");
		System.out.println("õ�� : " + (money % 5000) / 1000 + "��");
		System.out.println("����� : " + (money % 1000) / 500 + "��");
		System.out.println("��� : " + (money % 500) / 100 + "��");
	}
}



class CurrentCount{
	
	private int m5,m1,c5,c1,b5,b1;
	
	private int money;
	
	public CurrentCount(int money) {
		this.money = money;
		this.m5 = money/50000;
		this.m1 = (money%50000)/10000;
		this.c5 = (money%10000)/5000;
		this.c1 = (money%5000)/1000;
		this.b5 = (money%1000)/500;
		this.b1 = (money%500)/100;
	}
	
	public void show() {
		System.out.println(money);
		System.out.println("������ : " + m5 + "��");
		System.out.println("���� : " + m1 + "��");
		System.out.println("��õ�� : " + c5 + "��");
		System.out.println("õ�� : " + c1 + "��");
		System.out.println("����� : " + b5 + "��");
		System.out.println("��� : " + b1 + "��");
	}
	
	public int getM5() {
		int a;
		return m5;
	}

	public void setM5(int m5) {
		this.m5 = m5;
	}

	public int getM1() {
		return m1;
	}

	public void setM1(int m1) {
		this.m1 = m1;
	}

	public int getC5() {
		return c5;
	}

	public void setC5(int c5) {
		this.c5 = c5;
	}

	public int getC1() {
		return c1;
	}

	public void setC1(int c1) {
		this.c1 = c1;
	}

	public int getB5() {
		return b5;
	}

	public void setB5(int b5) {
		this.b5 = b5;
	}

	public int getB1() {
		return b1;
	}

	public void setB1(int b1) {
		this.b1 = b1;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}
}




//========================
public class GradeTest {

	public static void main(String[] args) {

		while(true) {
			Scanner scanner = new Scanner(System.in);
			
			/*
			int eng = scanner.nextInt();
			int math = scanner.nextInt();
			int kor = scanner.nextInt();
	
			Grade grade = new Grade(kor, math, eng);
			System.out.println(grade.getAvg());
			*/
			int money = scanner.nextInt();
			CurrentCount currentCount = new CurrentCount(money);
			currentCount.show();
			
			System.out.println("�����Ͻðڽ��ϱ�? ����:y ���:n");
			char stop = scanner.next().charAt(0);
			
			System.out.println("�������� " + currentCount.getM5());
			
			if((stop == 'Y') || (stop== 'y'))
				break;
			
			
			System.out.println("���¥�� " + currentCount.getB1());
		}
		
		System.out.println("���� �Ǿ����ϴ�.");

	}

}
