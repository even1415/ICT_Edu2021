package day01;

public abstract class Circle extends Shape{
	
	final double PI=3.14;

}
