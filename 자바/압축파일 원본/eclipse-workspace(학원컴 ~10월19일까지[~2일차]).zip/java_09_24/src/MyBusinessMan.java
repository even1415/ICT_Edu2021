class Man {
    String name;
    public void tellYourName() { 
        System.out.println("My name is " + name); 
    }
}

class BusinessMan extends Man {
    String company;
    String position;
    
    public BusinessMan(String name, String company, String position) {
        this.name = name;
        this.company = company;
        this.position = position;
    }

    public void tellYourInfo() {
        System.out.println("My company is " + company);
        System.out.println("My position is " + position);
        tellYourName();
    }
}
//Parent �ǵ����� ����
class Parent{
	int num;
	
	public Parent() {}
	
	public Parent(int num) {
		this.num = num;
	}
	
	public int getNum() {
		return num;
	}
}
//�θ� �ִ� ���� �ʱ�ȭ ���
//1.this �� ���� 2.super �ε� ���ٰ����ϴ�.

class Child extends Parent {
	
	private String name;
	
	public Child(int num,String name) {
		super(num); //this �Լ� ������ ȣ��
		
	}
	
	public void printNum() {
		System.out.println(this.name + "�� ���̰�" + super.getNum()+"�Դϴ�.");
	}
}


class MyBusinessMan {
    public static void main(String[] args) {
    	
    	Child child = new Child(3,"�ٵ���");
    	child.printNum();
    	
    	
    	
    	//BusinessMan man
        //            = new BusinessMan("YOON", "Hybrid ELD", "Staff Eng.");
        
	//man.tellYourInfo();
		
    }
}