class SuperCLS {
	
    public SuperCLS () {
        System.out.println("I'm Super Class");
    }
    
}

class SubCLS extends SuperCLS {
	
    public SubCLS () {
    	super();
        System.out.println("I'm Sub Class");
    }
    
}

//�����Ϸ��� ���� �������� ������ �־� �ִ°�?
class {
	int a;
}

class B {
	int a;
}

interface AA{
	
}

class C extends String , Math {
	
}

class AA{
	
}

class BB extends AA {
	
}

class CC extends BB {
	
}

class SuperSubCon {
    public static void main(String[] args) {
    	 //new SubCLS();
    	 B b = new B();
    	 
    	
    }
}