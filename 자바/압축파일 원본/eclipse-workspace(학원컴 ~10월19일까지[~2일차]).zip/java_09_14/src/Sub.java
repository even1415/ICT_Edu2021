import java_09_14_sub.Super;

public class Sub extends Super{
	
	public void show() {
		System.out.println(num);
	}
	
}
