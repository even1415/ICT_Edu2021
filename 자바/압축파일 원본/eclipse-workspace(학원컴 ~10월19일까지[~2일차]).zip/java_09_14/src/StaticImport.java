import static java.lang.Math.*;
class Star{
	
}

class StaticTest {
	
	static int a;
	
	
    public static void main(String[] args) {
    	
    	int b;
    	
    	
        System.out.println(E);
        System.out.println(PI);

        System.out.println(abs(-55));    // ���� ��ȯ
        System.out.println(max(77, 88));   // ū �� ��ȯ
        System.out.println(min(33, 55));   // ���� �� ��ȯ
    }
}
