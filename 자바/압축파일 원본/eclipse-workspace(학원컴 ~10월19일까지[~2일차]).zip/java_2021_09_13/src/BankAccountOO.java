class BankAccount {
    int balance = 0;     // ���� �ܾ�

    public int deposit(int amount) {
        balance += amount;
        return balance;
    }    

    public int withdraw(int amount) {
        balance -= amount;
        return balance;
    }

    public int checkMyBalance() {
        System.out.println("�ܾ� : " + balance);
        return balance;
    }
}
	

class BankAccountOO {
    public static void main(String[] args) {
    	final int COUNT = 2021;
    	
        int count_num = 0;
        int num =0; 
    	for(int i=0;i < Integer.MAX_VALUE;i++) {
    		
    		
    		if(i%2==0 || i%7 ==0) {
    			count_num++; 
    			
    		}
    		
    		if(count_num == COUNT) {
    			num = ++i;
    			break;
    		}
    			
    		
    	}
    	System.out.println(num);
    			
    }
}