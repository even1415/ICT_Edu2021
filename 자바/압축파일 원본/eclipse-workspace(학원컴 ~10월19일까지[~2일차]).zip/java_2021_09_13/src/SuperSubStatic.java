import java_protected.Circle;

//count =3; 
class SuperCLS {
    protected static int count = 0;

    public SuperCLS() {
        count++;
    }
}

class SubCLS extends SuperCLS {
	Circle circle = new Circle();
	
	SubCLS(){
		super();
	}
	
	public void showCount() {
		circle.num = 1;
        System.out.println(count);
    }
}

class SuperSubStatic {
    public static void main(String[] args) {
    	   	
        SuperCLS obj1 = new SuperCLS();
        SuperCLS obj2 = new SuperCLS();
        
        SubCLS obj3 = new SubCLS();
        obj3.showCount();
    }
}