package java_protected;

public class Super {
	protected int num;
}

