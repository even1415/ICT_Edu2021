package a;

import b.B;

public class A {
	B b = new B();
}
