package b;

class B {

}
