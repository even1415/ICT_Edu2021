package b;

class C {
	B b = new B();
}
