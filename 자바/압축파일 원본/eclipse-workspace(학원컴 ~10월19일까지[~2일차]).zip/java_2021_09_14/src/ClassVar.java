class Point {
	private int x, y;
	
	public Point() {
		
	}
	
	public Point(int x, int y) { 
		this.x = x; 
		this.y = y; 
	}

	public int getX() { 
		return x; 
	}
	public int getY() { 
		return y; 
	}
	protected void move(int x, int y) { 
		this.x =x; 						
		this.y = y;    		
	}
}



class Point3D extends Point {
	private int z;
	
	public int getZ() {
		return z;
	}

	public Point3D(int x, int y, int z) {
	//super.move(x, y);
	//this.z = z;
		this.move(x, y, z);
	}
	
	//public void move(int x, int y) {
	//	super.move(x, y);
	//}
	
	public void move(int x, int y, int z) {
		super.move(x, y);
		this.z = z;
	}

	public int moveUp() {
		return this.z = this.z + 1;
	}

	public void moveDown() {
		this.z = this.z -1;
	}
	
	public String toString() {
		return "("+ super.getX()+", "+ super.getY()+", "+ this.getZ()+ ")�� ��";
	}
}

/*
=======================
(1,2,3) �� ���Դϴ�.
(1,2,4) �� ���Դϴ�.

(10,10,3) �� ���Դϴ�.
(100,200,300) �� ���Դϴ�.
*/

//D d = (D) new C();
//�ڽ� = (�ڽ�) �θ�
//D d = (D) new C();

class A {
	public void printA() {
		System.out.println("A");
	}
}

class B extends A {
	public void printB() {
		System.out.println("B");
	}
}


class C extends B {
	public void printC() {
		System.out.println("C");
	}
}
//A a = new C();

class ClassVar {
    public static void main(String[] args) {
    	
    	A a = new B();
    	a.printB();
    	
    	Point3D p = new Point3D(1,2,3); // 1,2,3�� ���� x, y, z���� ��.
    	
    	System.out.println(p.toString()+"�Դϴ�.");
    	
    	p.moveUp(); // z ������ ���� �̵�
    	
    	System.out.println(p.toString()+"�Դϴ�.");
    	
    	p.moveDown(); // z ������ �Ʒ��� �̵�
    	p.move(10, 10); // x, y ������ �̵�
    	
    	System.out.println(p.toString()+"�Դϴ�.");
    	
    	p.move(100,  200, 300); // x, y, z������ �̵�
    	System.out.println(p.toString()+"�Դϴ�.");

    }
}