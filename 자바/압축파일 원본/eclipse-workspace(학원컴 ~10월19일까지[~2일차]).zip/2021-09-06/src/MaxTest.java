
public class MaxTest {

	public static void main(String[] args) {
		int num1 = 80;
		int num2 = 33;
		int num3 = 55;
		int max = 0;
		
		if(num1 > num2) {
			if(num1 > num3) {
				max = num1;
			}else {
				max = num3;
			}
		}else {
			if(num2 > num3) {
				max = num2;
			}else {
				max = num3;
			}			
		}
		
		if((num1 > num2) && (num1 > num3)) {
			max = num1;
		}else if((num2 > num1) && (num2 > num3)) {
			max = num2;
		}else {
			max  = num3;
		}
		
		
		
		System.out.println("�ִ밪 �Դϴ�=" + max);
	}

}
