import java.util.Scanner;

class LexiCount{
	
	private int consonant=0;  //���� ���� 
	private int vowel=0;      //���� ����
	private String word;	
	
	private void getInput() {
		Scanner scanner = new Scanner(System.in);
    	
    	System.out.println("���� �ܾ �Է��ϼ���.");
    	word = scanner.next();
    	scanner.close();
	}
	
	private void countText() {
		for(int i = 0; i < word.length() ;i++) {
    		char ch = word.charAt(i);
    		
    		switch(ch) {      
			
			case 'a':			
			case 'e':				
			case 'i':				
			case 'o':				
			case 'u':
			case 'A':			
			case 'E':				
			case 'I':				
			case 'O':				
			case 'U':
				vowel++;
				break;
			default:
				consonant++;
			}
    		
    	}
		
		
	}
	
	private void printResult() {
		System.out.println("�� ���� ����: "+ word.length()+"�� �Դϴ�.");
		System.out.println("������ : " + vowel + "�� �Դϴ�.");
		System.out.println("������ : " + consonant + "�� �Դϴ�.");
	}
	
	public void run() {
		getInput();
		countText();
		printResult();
	}
	
}


class Calculate {
	
	private int num1;
	private char op;
	private int num2;
	
	int[] ref;
	int ref2[];
	
	
	public void getInput() {
		Scanner sc = new Scanner(System.in);

		System.out.println("ù ��° ���ڸ� �Է��ϼ���.");
		num1 = sc.nextInt();

		System.out.println("���� ��ȣ�� �Է��ϼ���.");
		op = sc.next().charAt(0);

		System.out.println("�� ��° ���ڸ� �Է��ϼ���.");
		num2 = sc.nextInt();
		

		
	}
	
	public void printCalulate() {
		int result = 0;
		
	    switch (op) {
        case '+':
            result = num1 + num2;
            break;
        case '-':
        	result = num1 - num2;
            break;
        case '*':
        	result = num1 * num2;
            break;
        case '/':
        	result = num1 / num2;
            break; 
        default:
            System.out.println("Error!");
        }
	    
	    System.out.println(result);
	}
	
	public boolean bClose() {
		boolean con = true;
		
		Scanner scanner = new Scanner(System.in);		
		System.out.println("�����Ͻðڽ��ϱ�? ����:y ���:n");
		char stop = scanner.next().charAt(0);
		
				
		if((stop == 'Y') || (stop== 'y'))
			con = true;
		else
			con = false;
		
		
		return con;
			
	}
	
	
	public void run() {
		
		while(true) {
			getInput(); 
			printCalulate();			
			
			if(bClose() == true)
				break;		
			
		}
		
		System.out.println("�����Դϴ�.");
		
	}
}


public class CalculatorTest {
	public static void main(String[] args) {
		
		int[] ref;
		ref = new int[5];
		
		System.out.println(ref[0]);
		System.out.println(ref[1]);
		System.out.println(ref[2]);
		System.out.println(ref[3]);
		System.out.println(ref[4]);
		
		//System.out.println(ref[5]);
		
		
		//Calculate calculate = new Calculate();
		//calculate.run();
	}
}
