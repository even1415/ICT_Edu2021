class StringConcat {
    public static void main(String[] args) {
        String st1 = "Coffee";
        String st2 = "Coffee";
        
         //Returns:the value 0 if the argument string is equal tothis string; a value less than 0 if this stringis lexicographically less than the string argument; and avalue greater than 0 if this string islexicographically greater than the string argument.
        		
        if(st1.compareTo(st2) == 0)
        	System.out.println("���� ����");
        else if(st1.compareTo(st2) > 0)
        	System.out.println("str1�� �������� �ڿ� ���Ϳ�");
        else if(st1.compareTo(st2) < 0)
        	System.out.println("str1�� �������� �տ� ���Ϳ�");
        
        String st3 = st1.concat(st2);
        
        System.out.println(st1);
        
        System.out.println(st3);

        String st4 = "Fresh".concat(st3);
        System.out.println(st4);
    }
}