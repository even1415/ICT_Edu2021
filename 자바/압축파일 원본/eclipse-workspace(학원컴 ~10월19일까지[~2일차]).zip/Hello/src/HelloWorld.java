
public class HelloWorld {

	public static void main(String[] args) {
		//문자가 뿌려지는 원리는 문자와 숫자의 일대일 매칭
		
		//A = 65
		//B = 66
		//이라고 우리 교수님들이 약속(표준)을 그렇게 했기 때문입니다.
		//방법이 그것 밖에 없기 때문에 
		//영어만 정의 했음
		
		//ASC + 한글 + 중국어 + 일본어 ......  = 유니코드 = UTF-8 = UTF-16
		char ch = '가';
		
		
		System.out.println(ch);
	}

}
