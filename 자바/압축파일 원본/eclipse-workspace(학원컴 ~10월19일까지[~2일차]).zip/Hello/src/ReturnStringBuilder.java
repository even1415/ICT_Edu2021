

class ReturnStringBuilder {
    public static void main(String[] args) {
        
    	String s1  = "Hello";
    	s1  = s1 + s1;
    	
    	
    	StringBuilder stb1 = new StringBuilder("hello");
    	stb1.append("hello");
    	
    	for(int i=0;i<10000;i++) {
    		 s1  = s1 + s1;
    		 stb1.append("hello");
    	}
        
        

    }
}