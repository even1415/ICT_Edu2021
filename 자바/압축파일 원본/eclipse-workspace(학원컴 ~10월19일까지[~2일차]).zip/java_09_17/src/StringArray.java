class StringArray {

	
    public static void main(String[] args) {
    	final int ROWS = 4;
    	final int COLS = 4;
    	
    	int[][] arr = new int[ROWS][COLS];
    	
    	//�Է�
    	for(int i=0 ; i < ROWS ; i++) {
    		for(int j=0 ; j < COLS ; j++) {
    			arr[i][j] = (int)(Math.random()*16 + 1);
        	}
    	}
    	
    	//���
    	for(int i=0 ; i < 3 ; i++) {
    		for(int j=0 ; j < arr[i].length ; j++) {
    			System.out.print(arr[i][j] +  " ");
        	}
    		System.out.println();
    	}
    	
    	final int ALPABET_COUNT = 26;
    	
    	char[] alpa = new char[ALPABET_COUNT];
    	
    	for(int i=0 ; i < ALPABET_COUNT ; i++) {
    		alpa[i] = (char)('A' + i);
    	}
    	
    	for (char c : alpa) {
			System.out.println(c);
		}
    	
    	
    	
    	
    }
}