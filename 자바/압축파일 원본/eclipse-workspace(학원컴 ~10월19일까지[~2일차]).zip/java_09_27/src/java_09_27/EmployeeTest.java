class Employee{
	private String name;
	private int age;
	private String address;
	private String dept;
	private int salary;
	
	public Employee() {
	}
	
	public Employee(String name, int age, String address, String dept) {
		this.name = name;
		this.age = age;
		this.address = address;
		this.dept = dept;
	}
	
	public void printInfo() {
		System.out.println("�̸� : " + this.name);
		System.out.println("���� : " + this.age);
		System.out.println("�ּ� : " + this.address);
		System.out.println("�μ� : " + this.dept);
		//System.out.println("���� : " + this.salary);
	}

	public void setSalary(int salary) {
		this.salary = salary;		
	}
	
	public int getSalary() {
		return salary;
	}
}

class Regular extends Employee{	
	
	public Regular(String name, int age, String address, String dept, int salary) {
		super(name, age, address, dept);
		super.setSalary(salary);
	}
	@Override
	public void printInfo() {
		super.printInfo();
		System.out.println("���� : " + super.getSalary());
	}
	
	
}

class Temporary{
	
}



public class EmployeeTest {

	public static void main(String[] args) {
		Employee employee = new Employee("�ٵ���", 9, "����", "���μ�");
		employee.printInfo();
		
		Employee employee2 = new Regular("��ö��", 26, "�����", "������", 2_500_000);
		employee2.printInfo();


	}

}