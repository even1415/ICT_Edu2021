class SwitchBasic {
    public static void main(String[] args) {
        int month = 2;
        
        String str = "spring";
        
        //
        switch(month) {        
        case 1:case 2:
            System.out.println("���Դϴ�");
        case "winter":
            System.out.println("Funny Java");
        case "fall":
            System.out.println("Fantastic Java");
            break;
        default:
            System.out.println("The best programming language");
        }
        
        System.out.println("Do you like Java?");
    }
}