
public class Grade {

	public static void main(String[] args) {
		char ch = 'A';
		System.out.println(ch);
		
		char a = 65;
		
		char num1 = 'A';
		char num2 = 'B';
		int num3 = num1 +  num2;
		
		
		System.out.println(a);
		

	}

}
