
public class Logical {

	public static void main(String[] args) {
		

	}

}
