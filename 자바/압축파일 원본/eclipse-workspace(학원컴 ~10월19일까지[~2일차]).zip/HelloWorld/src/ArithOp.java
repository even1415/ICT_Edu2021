class A{
	int num;
	
	A(){
		System.out.println("����Ʈ ������");
	}
	
	A(int n){
		this();
		num = n;
		System.out.println(num);
	}
	
	A(int n,int n2){
		this(n2);
		System.out.println(num);
	}
}

class ArithOp {
    public static void main(String[] args) {
        //A a = new A();
        A b = new A(0,3);
        
    
    }
}