class PostfixOp {
    public static void main(String[] args) {
        int num = 5;

        System.out.print((num++) + " ") ; 
        System.out.print((num++) + " ") ;
        System.out.println(num);//7

        System.out.print((num--) + " "); //7
        System.out.print((num--) + " "); //6
        System.out.print(num);//5
    }
}