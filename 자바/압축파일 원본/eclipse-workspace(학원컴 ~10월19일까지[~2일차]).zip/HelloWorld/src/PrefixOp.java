class PrefixOp {
    public static void main(String[] args) {
        int num = 7;
        //++
        //num = num + 1 ;
        
        System.out.println(num = num + 1);
        
        System.out.println(num = num + 1);
        System.out.println(num);	
    }
}