package day11;
import java.io.*;

/*
 * 
 * */

public class FileInputStreamTest {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		String file = "C:\\Users\\ict01-16\\eclipse-workspace\\MyJava\\src\\day11\\InputStreamTest.java";
		//�����ͼҽ� : ���� => FileInputStream
		
		FileInputStream fis = new FileInputStream(file);
		//���ϰ� ��� ����
		
		int n=0, count = 0;
		
		while((n=fis.read())!= -1) {
			System.out.write(n);
			count++;
		}
		System.out.println("�� " + count + " bytes");
		fis.close();
		System.out.close();
	}

}
