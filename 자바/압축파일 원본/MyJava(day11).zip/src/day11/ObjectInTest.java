package day11;
import java.io.*;
import java.util.*;
import javax.swing.*;

public class ObjectInTest {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		//ObjectOutTest ���� �Ŀ� ObjectInTest �����ؾ���
		
		//1. obj.txt ���� �о ��ü ����
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("src/day11/obj.txt"));
		
		//2. readUTF() / readObject(), readObject() ȣ���ؼ� �ֿܼ� ���
		//JFrame�� setSize()
		//setVisible(true)

		String str = ois.readUTF();
		System.out.println(str);
		
		Object obj = ois.readObject();
		Date date = (Date)obj;
		System.out.println(date);
		
		JFrame jf = (JFrame)ois.readObject();
		jf.setSize(200,200);
		jf.setVisible(true);
		
		
		//e1~3 �о print() ȣ��
		EmpVO e1 = (EmpVO)ois.readObject();
		e1.print();
		
		EmpVO e2 = (EmpVO)ois.readObject();
		e2.print();
		
		EmpVO e3 = (EmpVO)ois.readObject();
		e3.print();
		
		
		ois.close();
	}

}
