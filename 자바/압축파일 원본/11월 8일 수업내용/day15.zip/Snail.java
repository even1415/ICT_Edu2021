package day15;
import java.awt.Color;

/*java.lang.Runnable �������̽��� ��ӹ޾� �����ϴ� ���
 * - �߻�޼ҵ�: public void run()
 * */
import javax.swing.*;
import java.awt.*;
public class Snail extends JPanel implements Runnable{

	boolean isStop=false;
	JLabel lb;
	ImageIcon icon;
	public Snail() {
		setLayout(new BorderLayout());
		icon=new ImageIcon("images/T0.gif");
		lb=new JLabel(icon);
		add(lb,BorderLayout.CENTER);
		setBackground(Color.white);
	}
	@Override
	public void run(){
		for(int i=0;!isStop ;i++) {
			if(i>13) {
				i=0;
			}
			//System.out.println("�����̰� ����");
			icon=new ImageIcon("images/T"+i+".gif");
			lb.setIcon(icon);
			int sec=(int)(Math.random()*300);
			try {
				Thread.sleep(sec);
			}catch(InterruptedException e) {
				System.out.println(e);
				break;
			}
		}//for----
	}//run()------------------
	

}
